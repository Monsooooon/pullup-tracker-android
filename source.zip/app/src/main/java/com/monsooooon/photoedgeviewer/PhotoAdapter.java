package com.monsooooon.photoedgeviewer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.Holder> {
    public interface Listener {
        void onClick(int position);
        void onLongClick(int position);
    }

    private final Listener listener;
    private final List<PhotoItem> items = new ArrayList<>();
    private final Map<Long, Integer> selectedOrder = new HashMap<>();

    public PhotoAdapter(Listener listener) {
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submit(List<PhotoItem> photos) {
        items.clear();
        items.addAll(photos);
        notifyDataSetChanged();
    }

    public void setSelectedOrder(Map<Long, Integer> order) {
        selectedOrder.clear();
        selectedOrder.putAll(order);
        notifyDataSetChanged();
    }

    public PhotoItem getItem(int position) {
        return items.get(position);
    }

    public int size() {
        return items.size();
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).id;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_photo, parent, false);
        view.setLayoutParams(new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        RecyclerView recyclerView = (RecyclerView) holder.itemView.getParent();
        RecyclerView.LayoutManager lm = recyclerView.getLayoutManager();
        int spans = lm instanceof androidx.recyclerview.widget.GridLayoutManager
                ? ((androidx.recyclerview.widget.GridLayoutManager) lm).getSpanCount()
                : 3;
        int side = Math.max(1, recyclerView.getWidth() / spans);
        RecyclerView.LayoutParams lp = (RecyclerView.LayoutParams) holder.itemView.getLayoutParams();
        if (lp.width != side || lp.height != side) {
            lp.width = side;
            lp.height = side;
            holder.itemView.setLayoutParams(lp);
        }

        PhotoItem item = items.get(position);
        Glide.with(holder.thumb)
                .load(item.uri)
                .thumbnail(0.15f)
                .centerCrop()
                .into(holder.thumb);

        Integer order = selectedOrder.get(item.id);
        if (order == null) {
            holder.badge.setVisibility(View.GONE);
        } else {
            holder.badge.setVisibility(View.VISIBLE);
            holder.badge.setText(String.valueOf(order));
        }

        holder.itemView.setOnClickListener(v -> listener.onClick(holder.getBindingAdapterPosition()));
        holder.itemView.setOnLongClickListener(v -> {
            listener.onLongClick(holder.getBindingAdapterPosition());
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static final class Holder extends RecyclerView.ViewHolder {
        final ImageView thumb;
        final TextView badge;

        Holder(@NonNull View itemView) {
            super(itemView);
            thumb = itemView.findViewById(R.id.thumb);
            badge = itemView.findViewById(R.id.checkBadge);
        }
    }
}
