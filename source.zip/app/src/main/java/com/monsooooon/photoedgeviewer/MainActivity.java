package com.monsooooon.photoedgeviewer;

import android.Manifest;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.ScaleGestureDetector;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.exifinterface.media.ExifInterface;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.text.SimpleDateFormat;
import java.io.FileDescriptor;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends AppCompatActivity implements PhotoAdapter.Listener {
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private View galleryPanel;
    private View viewerPanel;
    private ImageView fullImage;
    private TextView viewerCounter;
    private TextView selectionText;
    private Button alignButton;
    private ProgressBar progress;
    private TextView currentAlbumText;
    private Button chooseAlbumButton;
    private RecyclerView photoGrid;
    private GridLayoutManager gridLayoutManager;
    private ScaleGestureDetector scaleGestureDetector;
    private int gridSpanCount = 3;

    private final List<PhotoItem> allPhotos = new ArrayList<>();
    private final List<PhotoItem> visiblePhotos = new ArrayList<>();
    private final LinkedHashMap<Long, PhotoItem> selected = new LinkedHashMap<>();
    private final List<String> albums = new ArrayList<>();
    private PhotoAdapter adapter;
    private int viewerIndex = 0;
    private String currentAlbum = "全部照片";
    private List<Uri> pendingWriteUris = Collections.emptyList();
    private long pendingMinTimeMs = 0L;

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) loadPhotos();
                else Toast.makeText(this, "需要照片读取权限", Toast.LENGTH_LONG).show();
            });

    private final ActivityResultLauncher<IntentSenderRequest> writeRequestLauncher =
            registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {
                    performTimeUpdate();
                } else {
                    Toast.makeText(this, "未获得修改照片权限", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        galleryPanel = findViewById(R.id.galleryPanel);
        viewerPanel = findViewById(R.id.viewerPanel);
        fullImage = findViewById(R.id.fullImage);
        viewerCounter = findViewById(R.id.viewerCounter);
        selectionText = findViewById(R.id.selectionText);
        alignButton = findViewById(R.id.alignButton);
        progress = findViewById(R.id.progress);
        currentAlbumText = findViewById(R.id.currentAlbumText);
        chooseAlbumButton = findViewById(R.id.chooseAlbumButton);
        photoGrid = findViewById(R.id.photoGrid);

        adapter = new PhotoAdapter(this);
        gridLayoutManager = new GridLayoutManager(this, gridSpanCount);
        photoGrid.setLayoutManager(gridLayoutManager);
        photoGrid.setHasFixedSize(true);
        photoGrid.setItemViewCacheSize(18);
        photoGrid.setAdapter(adapter);
        setupPinchZoom();

        chooseAlbumButton.setOnClickListener(v -> showAlbumPicker());
        currentAlbumText.setOnClickListener(v -> showAlbumPicker());
        alignButton.setOnClickListener(v -> requestAlignSelected());
        findViewById(R.id.leftEdge).setOnClickListener(v -> showPrevious());
        findViewById(R.id.rightEdge).setOnClickListener(v -> showNext());
        findViewById(R.id.closeViewer).setOnClickListener(v -> closeViewer());

        requestPermissionOrLoad();
    }


    private void setupPinchZoom() {
        scaleGestureDetector = new ScaleGestureDetector(this,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    private float accumulated = 1f;

                    @Override
                    public boolean onScaleBegin(ScaleGestureDetector detector) {
                        accumulated = 1f;
                        return true;
                    }

                    @Override
                    public boolean onScale(ScaleGestureDetector detector) {
                        accumulated *= detector.getScaleFactor();

                        int next = gridSpanCount;
                        if (accumulated < 0.78f) {
                            next = Math.min(7, gridSpanCount + 1);
                            accumulated = 1f;
                        } else if (accumulated > 1.28f) {
                            next = Math.max(2, gridSpanCount - 1);
                            accumulated = 1f;
                        }

                        if (next != gridSpanCount) {
                            int first = gridLayoutManager.findFirstVisibleItemPosition();
                            gridSpanCount = next;
                            gridLayoutManager.setSpanCount(gridSpanCount);
                            gridLayoutManager.requestLayout();
                            if (first >= 0) {
                                gridLayoutManager.scrollToPositionWithOffset(first, 0);
                            }
                        }
                        return true;
                    }
                });

        photoGrid.setOnTouchListener((view, event) -> {
            scaleGestureDetector.onTouchEvent(event);
            return scaleGestureDetector.isInProgress();
        });
    }

    private void requestPermissionOrLoad() {
        String permission = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            loadPhotos();
        } else {
            permissionLauncher.launch(permission);
        }
    }

    private void loadPhotos() {
        progress.setVisibility(View.VISIBLE);
        io.execute(() -> {
            List<PhotoItem> result = queryPhotos();
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                allPhotos.clear();
                allPhotos.addAll(result);
                rebuildAlbums();
                applyAlbumFilter();
                if (result.isEmpty()) {
                    Toast.makeText(this, "没有读取到照片", Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private List<PhotoItem> queryPhotos() {
        List<PhotoItem> result = new ArrayList<>();
        Uri collection = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Images.Media.DATE_TAKEN,
                MediaStore.Images.Media.DATE_MODIFIED,
                MediaStore.Images.Media.MIME_TYPE
        };

        String sort = MediaStore.Images.Media.DATE_TAKEN + " DESC, " +
                MediaStore.Images.Media.DATE_MODIFIED + " DESC";

        try (Cursor cursor = getContentResolver().query(collection, projection, null, null, sort)) {
            if (cursor == null) return result;
            int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            int bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME);
            int takenCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN);
            int modifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
            int mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);

            while (cursor.moveToNext()) {
                long id = cursor.getLong(idCol);
                Uri uri = ContentUris.withAppendedId(collection, id);
                result.add(new PhotoItem(
                        id,
                        uri,
                        cursor.getString(nameCol),
                        cursor.getString(bucketCol),
                        cursor.getLong(takenCol),
                        cursor.getLong(modifiedCol),
                        cursor.getString(mimeCol)
                ));
            }
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this,
                    "读取照片失败：" + e.getMessage(), Toast.LENGTH_LONG).show());
        }
        return result;
    }

    private void rebuildAlbums() {
        Set<String> set = new LinkedHashSet<>();
        set.add("全部照片");
        for (PhotoItem item : allPhotos) set.add(item.bucket);
        albums.clear();
        albums.addAll(set);
        if (!albums.contains(currentAlbum)) currentAlbum = "全部照片";
        currentAlbumText.setText(currentAlbum);
    }

    private void showAlbumPicker() {
        if (albums.isEmpty()) {
            Toast.makeText(this, "暂时没有可选择的相册", Toast.LENGTH_SHORT).show();
            return;
        }
        int checked = Math.max(0, albums.indexOf(currentAlbum));
        String[] names = albums.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("选择相册")
                .setSingleChoiceItems(names, checked, (dialog, which) -> {
                    currentAlbum = albums.get(which);
                    currentAlbumText.setText(currentAlbum);
                    selected.clear();
                    updateSelectionUi();
                    applyAlbumFilter();
                    dialog.dismiss();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void applyAlbumFilter() {
        visiblePhotos.clear();
        if ("全部照片".equals(currentAlbum)) visiblePhotos.addAll(allPhotos);
        else for (PhotoItem item : allPhotos) if (currentAlbum.equals(item.bucket)) visiblePhotos.add(item);
        adapter.submit(visiblePhotos);
        selectionText.setText("当前相册：" + currentAlbum + " · " + visiblePhotos.size() + " 张；长按照片选择两张");
    }

    @Override
    public void onClick(int position) {
        if (position < 0 || position >= visiblePhotos.size()) return;
        viewerIndex = position;
        openViewer();
    }

    @Override
    public void onLongClick(int position) {
        if (position < 0 || position >= visiblePhotos.size()) return;
        PhotoItem item = visiblePhotos.get(position);
        if (selected.containsKey(item.id)) {
            selected.remove(item.id);
        } else {
            if (selected.size() >= 2) {
                Long first = selected.keySet().iterator().next();
                selected.remove(first);
            }
            selected.put(item.id, item);
        }
        updateSelectionUi();
    }

    private void updateSelectionUi() {
        Map<Long, Integer> order = new LinkedHashMap<>();
        int n = 1;
        for (Long id : selected.keySet()) order.put(id, n++);
        adapter.setSelectedOrder(order);
        alignButton.setEnabled(selected.size() == 2);
        selectionText.setText(selected.size() == 2
                ? "已选择两张，点击“统一时间”"
                : "长按照片选择两张（已选 " + selected.size() + " 张）");
    }

    private void openViewer() {
        galleryPanel.setVisibility(View.GONE);
        viewerPanel.setVisibility(View.VISIBLE);
        renderViewer(false);
    }

    private void closeViewer() {
        viewerPanel.setVisibility(View.GONE);
        galleryPanel.setVisibility(View.VISIBLE);
    }

    private void showPrevious() {
        if (visiblePhotos.isEmpty()) return;
        viewerIndex = (viewerIndex - 1 + visiblePhotos.size()) % visiblePhotos.size();
        renderViewer(true);
    }

    private void showNext() {
        if (visiblePhotos.isEmpty()) return;
        viewerIndex = (viewerIndex + 1) % visiblePhotos.size();
        renderViewer(true);
    }

    private void renderViewer(boolean animate) {
        if (visiblePhotos.isEmpty()) return;
        PhotoItem item = visiblePhotos.get(viewerIndex);
        Runnable load = () -> {
            Glide.with(this)
                    .load(item.uri)
                    .fitCenter()
                    .into(fullImage);
            viewerCounter.setText((viewerIndex + 1) + " / " + visiblePhotos.size());
            fullImage.animate().alpha(1f).setDuration(180).start();
        };
        if (animate) {
            fullImage.animate().alpha(0f).setDuration(140).withEndAction(load).start();
        } else {
            fullImage.setAlpha(1f);
            load.run();
        }
    }

    private void requestAlignSelected() {
        if (selected.size() != 2) return;
        List<PhotoItem> two = new ArrayList<>(selected.values());
        long a = two.get(0).dateModifiedSec > 0
                ? two.get(0).dateModifiedSec * 1000L
                : two.get(0).effectiveTimeMs();
        long b = two.get(1).dateModifiedSec > 0
                ? two.get(1).dateModifiedSec * 1000L
                : two.get(1).effectiveTimeMs();
        long now = System.currentTimeMillis();
        pendingMinTimeMs = Math.min(a > 0 ? a : now, b > 0 ? b : now);
        pendingWriteUris = List.of(two.get(0).uri, two.get(1).uri);

        if (Build.VERSION.SDK_INT >= 30) {
            try {
                PendingIntent pi = MediaStore.createWriteRequest(getContentResolver(), pendingWriteUris);
                IntentSenderRequest request = new IntentSenderRequest.Builder(pi.getIntentSender()).build();
                writeRequestLauncher.launch(request);
            } catch (Exception e) {
                Toast.makeText(this, "请求修改权限失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            performTimeUpdate();
        }
    }

    private void performTimeUpdate() {
        progress.setVisibility(View.VISIBLE);
        io.execute(() -> {
            int success = 0;
            List<String> errors = new ArrayList<>();
            String exifDate = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.getDefault())
                    .format(new Date(pendingMinTimeMs));

            for (Uri uri : pendingWriteUris) {
                boolean exifUpdated = false;
                boolean mediaStoreUpdated = false;

                try (android.os.ParcelFileDescriptor pfd =
                             getContentResolver().openFileDescriptor(uri, "rw")) {
                    if (pfd == null) throw new IOException("无法打开照片文件");
                    FileDescriptor fd = pfd.getFileDescriptor();
                    ExifInterface exif = new ExifInterface(fd);
                    exif.setAttribute(ExifInterface.TAG_DATETIME, exifDate);
                    exif.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, exifDate);
                    exif.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, exifDate);
                    exif.saveAttributes();

                    // saveAttributes() 会把文件修改时间刷新为“现在”。
                    // 通过当前已授权的文件描述符把 mtime 恢复成两张照片中的较早值。
                    String fdPath = "/proc/self/fd/" + pfd.getFd();
                    try {
                        Files.setLastModifiedTime(
                                Paths.get(fdPath),
                                FileTime.fromMillis(pendingMinTimeMs)
                        );
                    } catch (Exception ignored) {
                        // 某些系统不允许通过 /proc/self/fd 恢复 mtime。
                        // EXIF 写入成功时仍继续同步媒体库，避免整个操作判定失败。
                    }
                    exifUpdated = true;
                } catch (Exception e) {
                    errors.add("照片时间写入失败：" + safeMessage(e));
                }

                try {
                    ContentValues values = new ContentValues();
                    // DATE_MODIFIED 是只读列，它会从实际文件 mtime 重新索引。
                    values.put(MediaStore.Images.Media.DATE_TAKEN, pendingMinTimeMs);
                    int rows = getContentResolver().update(uri, values, null, null);
                    mediaStoreUpdated = rows > 0;
                } catch (Exception e) {
                    errors.add("媒体库时间同步失败：" + safeMessage(e));
                }

                if (exifUpdated || mediaStoreUpdated) success++;
            }

            int finalSuccess = success;
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                        .format(new Date(pendingMinTimeMs));
                if (finalSuccess == 2) {
                    Toast.makeText(this,
                            "两张照片的拍摄时间和文件修改时间已统一为 " + date +
                                    "。若系统相册未立即变化，请关闭后重新打开相册。",
                            Toast.LENGTH_LONG).show();
                    selected.clear();
                    updateSelectionUi();
                    loadPhotos();
                } else {
                    String detail = errors.isEmpty() ? "系统拒绝修改照片元数据" : errors.get(0);
                    Toast.makeText(this,
                            "只成功修改 " + finalSuccess + " 张。原因：" + detail,
                            Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.isBlank() ? e.getClass().getSimpleName() : message;
    }

    @Override
    public void onBackPressed() {
        if (viewerPanel.getVisibility() == View.VISIBLE) closeViewer();
        else super.onBackPressed();
    }
}
