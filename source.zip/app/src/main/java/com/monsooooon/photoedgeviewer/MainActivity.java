package com.monsooooon.photoedgeviewer;

import android.Manifest;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends AppCompatActivity implements PhotoAdapter.Listener {
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private View galleryPanel;
    private View viewerPanel;
    private ImageView fullImage;
    private TextView viewerCounter;
    private TextView selectionText;
    private Button alignButton;
    private ProgressBar progress;
    private Spinner albumSpinner;
    private RecyclerView photoGrid;

    private final List<PhotoItem> allPhotos = new ArrayList<>();
    private final List<PhotoItem> visiblePhotos = new ArrayList<>();
    private final LinkedHashMap<Long, PhotoItem> selected = new LinkedHashMap<>();
    private final List<String> albums = new ArrayList<>();
    private PhotoAdapter adapter;
    private int viewerIndex = 0;
    private List<Uri> pendingWriteUris = Collections.emptyList();
    private long pendingMinTimeMs = 0L;

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) loadPhotos();
                else Toast.makeText(this, "需要照片读取权限", Toast.LENGTH_LONG).show();
            });

    private final ActivityResultLauncher<IntentSenderRequest> writeRequestLauncher =
            registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {
                    performTimeUpdate();
                } else {
                    Toast.makeText(this, "未获得修改照片权限", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        galleryPanel = findViewById(R.id.galleryPanel);
        viewerPanel = findViewById(R.id.viewerPanel);
        fullImage = findViewById(R.id.fullImage);
        viewerCounter = findViewById(R.id.viewerCounter);
        selectionText = findViewById(R.id.selectionText);
        alignButton = findViewById(R.id.alignButton);
        progress = findViewById(R.id.progress);
        albumSpinner = findViewById(R.id.albumSpinner);
        photoGrid = findViewById(R.id.photoGrid);

        adapter = new PhotoAdapter(this);
        photoGrid.setLayoutManager(new GridLayoutManager(this, 3));
        photoGrid.setHasFixedSize(true);
        photoGrid.setItemViewCacheSize(18);
        photoGrid.setAdapter(adapter);

        albumSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> applyAlbumFilter()));
        alignButton.setOnClickListener(v -> requestAlignSelected());
        findViewById(R.id.leftEdge).setOnClickListener(v -> showPrevious());
        findViewById(R.id.rightEdge).setOnClickListener(v -> showNext());
        findViewById(R.id.closeViewer).setOnClickListener(v -> closeViewer());

        requestPermissionOrLoad();
    }

    private void requestPermissionOrLoad() {
        String permission = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            loadPhotos();
        } else {
            permissionLauncher.launch(permission);
        }
    }

    private void loadPhotos() {
        progress.setVisibility(View.VISIBLE);
        io.execute(() -> {
            List<PhotoItem> result = queryPhotos();
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                allPhotos.clear();
                allPhotos.addAll(result);
                rebuildAlbums();
                applyAlbumFilter();
                if (result.isEmpty()) {
                    Toast.makeText(this, "没有读取到照片", Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private List<PhotoItem> queryPhotos() {
        List<PhotoItem> result = new ArrayList<>();
        Uri collection = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Images.Media.DATE_TAKEN,
                MediaStore.Images.Media.DATE_MODIFIED,
                MediaStore.Images.Media.MIME_TYPE
        };

        String sort = MediaStore.Images.Media.DATE_TAKEN + " DESC, " +
                MediaStore.Images.Media.DATE_MODIFIED + " DESC";

        try (Cursor cursor = getContentResolver().query(collection, projection, null, null, sort)) {
            if (cursor == null) return result;
            int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            int bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME);
            int takenCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN);
            int modifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
            int mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);

            while (cursor.moveToNext()) {
                long id = cursor.getLong(idCol);
                Uri uri = ContentUris.withAppendedId(collection, id);
                result.add(new PhotoItem(
                        id,
                        uri,
                        cursor.getString(nameCol),
                        cursor.getString(bucketCol),
                        cursor.getLong(takenCol),
                        cursor.getLong(modifiedCol),
                        cursor.getString(mimeCol)
                ));
            }
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this,
                    "读取照片失败：" + e.getMessage(), Toast.LENGTH_LONG).show());
        }
        return result;
    }

    private void rebuildAlbums() {
        Set<String> set = new LinkedHashSet<>();
        set.add("全部照片");
        for (PhotoItem item : allPhotos) set.add(item.bucket);
        albums.clear();
        albums.addAll(set);
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                albums
        );
        albumSpinner.setAdapter(spinnerAdapter);
    }

    private void applyAlbumFilter() {
        if (albums.isEmpty()) return;
        int pos = albumSpinner.getSelectedItemPosition();
        String album = pos <= 0 ? "全部照片" : albums.get(pos);
        visiblePhotos.clear();
        if ("全部照片".equals(album)) visiblePhotos.addAll(allPhotos);
        else for (PhotoItem item : allPhotos) if (album.equals(item.bucket)) visiblePhotos.add(item);
        adapter.submit(visiblePhotos);
    }

    @Override
    public void onClick(int position) {
        if (position < 0 || position >= visiblePhotos.size()) return;
        viewerIndex = position;
        openViewer();
    }

    @Override
    public void onLongClick(int position) {
        if (position < 0 || position >= visiblePhotos.size()) return;
        PhotoItem item = visiblePhotos.get(position);
        if (selected.containsKey(item.id)) {
            selected.remove(item.id);
        } else {
            if (selected.size() >= 2) {
                Long first = selected.keySet().iterator().next();
                selected.remove(first);
            }
            selected.put(item.id, item);
        }
        updateSelectionUi();
    }

    private void updateSelectionUi() {
        Map<Long, Integer> order = new LinkedHashMap<>();
        int n = 1;
        for (Long id : selected.keySet()) order.put(id, n++);
        adapter.setSelectedOrder(order);
        alignButton.setEnabled(selected.size() == 2);
        selectionText.setText(selected.size() == 2
                ? "已选择两张，点击“统一时间”"
                : "长按照片选择两张（已选 " + selected.size() + " 张）");
    }

    private void openViewer() {
        galleryPanel.setVisibility(View.GONE);
        viewerPanel.setVisibility(View.VISIBLE);
        renderViewer(false);
    }

    private void closeViewer() {
        viewerPanel.setVisibility(View.GONE);
        galleryPanel.setVisibility(View.VISIBLE);
    }

    private void showPrevious() {
        if (visiblePhotos.isEmpty()) return;
        viewerIndex = (viewerIndex - 1 + visiblePhotos.size()) % visiblePhotos.size();
        renderViewer(true);
    }

    private void showNext() {
        if (visiblePhotos.isEmpty()) return;
        viewerIndex = (viewerIndex + 1) % visiblePhotos.size();
        renderViewer(true);
    }

    private void renderViewer(boolean animate) {
        if (visiblePhotos.isEmpty()) return;
        PhotoItem item = visiblePhotos.get(viewerIndex);
        Runnable load = () -> {
            Glide.with(this)
                    .load(item.uri)
                    .fitCenter()
                    .into(fullImage);
            viewerCounter.setText((viewerIndex + 1) + " / " + visiblePhotos.size());
            fullImage.animate().alpha(1f).setDuration(180).start();
        };
        if (animate) {
            fullImage.animate().alpha(0f).setDuration(140).withEndAction(load).start();
        } else {
            fullImage.setAlpha(1f);
            load.run();
        }
    }

    private void requestAlignSelected() {
        if (selected.size() != 2) return;
        List<PhotoItem> two = new ArrayList<>(selected.values());
        long a = two.get(0).effectiveTimeMs();
        long b = two.get(1).effectiveTimeMs();
        pendingMinTimeMs = Math.min(a > 0 ? a : System.currentTimeMillis(),
                                    b > 0 ? b : System.currentTimeMillis());
        pendingWriteUris = List.of(two.get(0).uri, two.get(1).uri);

        if (Build.VERSION.SDK_INT >= 30) {
            try {
                PendingIntent pi = MediaStore.createWriteRequest(getContentResolver(), pendingWriteUris);
                IntentSenderRequest request = new IntentSenderRequest.Builder(pi.getIntentSender()).build();
                writeRequestLauncher.launch(request);
            } catch (Exception e) {
                Toast.makeText(this, "请求修改权限失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            performTimeUpdate();
        }
    }

    private void performTimeUpdate() {
        progress.setVisibility(View.VISIBLE);
        io.execute(() -> {
            int success = 0;
            List<String> errors = new ArrayList<>();
            for (Uri uri : pendingWriteUris) {
                try {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DATE_TAKEN, pendingMinTimeMs);
                    values.put(MediaStore.Images.Media.DATE_MODIFIED, pendingMinTimeMs / 1000L);
                    int rows = getContentResolver().update(uri, values, null, null);
                    if (rows > 0) success++;
                    else errors.add("系统未允许更新时间");
                } catch (Exception e) {
                    errors.add(e.getMessage());
                }
            }
            int finalSuccess = success;
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                if (finalSuccess == 2) {
                    String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                            .format(new Date(pendingMinTimeMs));
                    Toast.makeText(this, "两张照片已统一为 " + date, Toast.LENGTH_LONG).show();
                    selected.clear();
                    updateSelectionUi();
                    loadPhotos();
                } else {
                    Toast.makeText(this,
                            "成功 " + finalSuccess + " 张。部分手机系统不允许修改原照片时间。",
                            Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    @Override
    public void onBackPressed() {
        if (viewerPanel.getVisibility() == View.VISIBLE) closeViewer();
        else super.onBackPressed();
    }
}
