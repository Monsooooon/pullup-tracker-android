package com.monsooooon.photoedgeviewer;

import android.net.Uri;

public final class PhotoItem {
    public final long id;
    public final Uri uri;
    public final String name;
    public final String bucket;
    public final long dateTakenMs;
    public final long dateModifiedSec;
    public final String mimeType;

    public PhotoItem(long id, Uri uri, String name, String bucket,
                     long dateTakenMs, long dateModifiedSec, String mimeType) {
        this.id = id;
        this.uri = uri;
        this.name = name == null ? "" : name;
        this.bucket = (bucket == null || bucket.isBlank()) ? "其他" : bucket;
        this.dateTakenMs = dateTakenMs;
        this.dateModifiedSec = dateModifiedSec;
        this.mimeType = mimeType == null ? "" : mimeType;
    }

    public long effectiveTimeMs() {
        if (dateTakenMs > 0) return dateTakenMs;
        if (dateModifiedSec > 0) return dateModifiedSec * 1000L;
        return 0L;
    }
}
