package com.yang.pulluptracker;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    private SharedPreferences sp;
    private EditText input;
    private TextView todayView, monthView, streakView, lastView, historyView;
    private HeatmapView heatmap;
    private final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    public void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("pullup_data", MODE_PRIVATE);
        buildUi();
        refresh();
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundColor(Color.rgb(248,250,252));
        sv.addView(root);

        TextView title = text("💪 引体记录", 30, true);
        root.addView(title);
        TextView sub = text("每天输入计数器当前总数，自动计算今天完成数量", 14, false);
        sub.setTextColor(Color.rgb(100,116,139));
        root.addView(sub);

        input = new EditText(this);
        input.setHint("今天计数器读数");
        input.setTextSize(22);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setSingleLine(true);
        input.setPadding(dp(14), dp(12), dp(14), dp(12));
        root.addView(input, new LinearLayout.LayoutParams(-1, -2));

        Button save = new Button(this);
        save.setText("保存今天记录");
        save.setOnClickListener(v -> saveRecord(false));
        root.addView(save);

        Button reset = new Button(this);
        reset.setText("本月计数器已重置 / 从当前读数重新开始");
        reset.setOnClickListener(v -> saveRecord(true));
        root.addView(reset);

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.VERTICAL);
        root.addView(cards);
        todayView = card(cards, "今天", "0 个");
        monthView = card(cards, "本月", "0 个");
        streakView = card(cards, "连续训练", "0 天");
        lastView = card(cards, "上次读数", "暂无");

        TextView ht = text("近一年热力图", 20, true);
        root.addView(ht);
        heatmap = new HeatmapView(this);
        root.addView(heatmap, new LinearLayout.LayoutParams(-1, dp(150)));

        TextView hisTitle = text("最近记录", 20, true);
        root.addView(hisTitle);
        historyView = text("", 14, false);
        historyView.setTextColor(Color.rgb(51,65,85));
        root.addView(historyView);
        setContentView(sv);
    }

    private TextView card(LinearLayout parent, String label, String value) {
        TextView tv = text(label + "\n" + value, 24, true);
        tv.setPadding(dp(16), dp(14), dp(16), dp(14));
        tv.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, 0);
        parent.addView(tv, lp);
        return tv;
    }

    private TextView text(String s, int size, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(size);
        tv.setTextColor(Color.rgb(15,23,42));
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, dp(6), 0, dp(6));
        return tv;
    }

    private void saveRecord(boolean reset) {
        String s = input.getText().toString().trim();
        if (s.isEmpty()) { toast("请输入计数器读数"); return; }
        int value;
        try { value = Integer.parseInt(s); } catch(Exception e) { toast("请输入数字"); return; }
        String today = fmt.format(new Date());
        try {
            JSONArray arr = getRecords();
            int previous = -1;
            for (int i = arr.length() - 1; i >= 0; i--) {
                JSONObject o = arr.getJSONObject(i);
                if (!o.optBoolean("reset", false) && !o.optString("date").equals(today)) { previous = o.optInt("counter"); break; }
            }
            int daily = reset || previous < 0 ? 0 : Math.max(0, value - previous);
            JSONObject rec = new JSONObject();
            rec.put("date", today); rec.put("counter", value); rec.put("daily", daily); rec.put("reset", reset);
            for (int i = arr.length() - 1; i >= 0; i--) if (arr.getJSONObject(i).optString("date").equals(today)) arr.remove(i);
            arr.put(rec);
            sp.edit().putString("records", arr.toString()).apply();
            input.setText(""); hideKeyboard(); refresh();
            toast(reset ? "已记录为重置日" : "已保存");
        } catch(Exception e) { toast("保存失败：" + e.getMessage()); }
    }

    private JSONArray getRecords() throws JSONException { return new JSONArray(sp.getString("records", "[]")); }

    private Map<String,Integer> dailyMap() {
        Map<String,Integer> m = new HashMap<>();
        try { JSONArray arr = getRecords(); for (int i=0;i<arr.length();i++){ JSONObject o=arr.getJSONObject(i); m.put(o.getString("date"), o.optInt("daily",0)); } } catch(Exception ignored) {}
        return m;
    }

    private void refresh() {
        Map<String,Integer> m = dailyMap();
        String today = fmt.format(new Date());
        int td = m.containsKey(today) ? m.get(today) : 0;
        int month = 0, streak = 0; String ym = today.substring(0,7);
        Calendar c = Calendar.getInstance();
        for (int i=0;i<365;i++) {
            String d = fmt.format(c.getTime());
            int v = m.containsKey(d) ? m.get(d) : 0;
            if (d.startsWith(ym)) month += v;
            if (i==streak && v > 0) streak++; else if (i==streak) {}
            c.add(Calendar.DATE, -1);
        }
        todayView.setText("今天\n" + td + " 个");
        monthView.setText("本月\n" + month + " 个");
        streakView.setText("连续训练\n" + streak + " 天");
        try {
            JSONArray arr = getRecords();
            if (arr.length() > 0) {
                JSONObject o = arr.getJSONObject(arr.length()-1);
                lastView.setText("上次读数\n" + o.optInt("counter") + "（" + o.optString("date") + "）");
            }
            StringBuilder sb = new StringBuilder();
            for (int i=arr.length()-1, n=0; i>=0 && n<12; i--,n++) {
                JSONObject o=arr.getJSONObject(i);
                sb.append(o.optString("date")).append("  ").append(o.optInt("daily")).append(" 个  读数 ").append(o.optInt("counter"));
                if (o.optBoolean("reset",false)) sb.append("  重置");
                sb.append("\n");
            }
            historyView.setText(sb.length()==0 ? "暂无记录" : sb.toString());
        } catch(Exception ignored) {}
        heatmap.setData(m);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private void hideKeyboard() { ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0); }

    public class HeatmapView extends View {
        private Map<String,Integer> data = new HashMap<>();
        private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        public HeatmapView(Context c) { super(c); setPadding(0, dp(8), 0, dp(8)); }
        public void setData(Map<String,Integer> d) { data = d; invalidate(); }
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int cell = Math.max(dp(9), getWidth() / 60); int gap = dp(3);
            Calendar cal = Calendar.getInstance(); cal.add(Calendar.DATE, -364);
            int x = 0, y;
            for (int i=0;i<365;i++) {
                int dow = cal.get(Calendar.DAY_OF_WEEK) - 1;
                if (i > 0 && dow == 0) x += cell + gap;
                y = dow * (cell + gap) + dp(4);
                int v = data.containsKey(fmt.format(cal.getTime())) ? data.get(fmt.format(cal.getTime())) : 0;
                p.setColor(color(v));
                canvas.drawRoundRect(x, y, x+cell, y+cell, dp(2), dp(2), p);
                cal.add(Calendar.DATE, 1);
            }
        }
        private int color(int v) {
            if (v <= 0) return Color.rgb(226,232,240);
            if (v < 10) return Color.rgb(187,247,208);
            if (v < 30) return Color.rgb(74,222,128);
            if (v < 60) return Color.rgb(22,163,74);
            return Color.rgb(20,83,45);
        }
    }
}
