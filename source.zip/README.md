# 边缘相册 Photo Edge Viewer

功能：

- 读取 Android 系统媒体库中的全部相册和照片
- Glide 缩略图加载，适合数百到数千张照片
- 点击照片左右边缘切换，不需要左右滑动
- 淡出 / 淡入过渡
- 长按选择两张照片
- 请求系统授权后，把两张照片的 DATE_TAKEN / DATE_MODIFIED 统一为较早值
- 完全离线

## GitHub Actions

仓库原有 workflow 会执行：

```bash
unzip -o source.zip -d source
cd source
gradle assembleDebug
```

构建完成后在 Actions → 对应运行 → Artifacts 下载 APK。

## 说明

Android 11 及以上修改他人创建的媒体文件时会显示系统授权弹窗。部分厂商相册可能按自己的数据库或 EXIF 排序，因此即使 MediaStore 时间更新成功，也可能需要重启相册或重新扫描。


## 1.1 修复

- 顶部“选择相册”按钮弹出明确的相册列表
- 修改时间时同时写入 EXIF DateTime/DateTimeOriginal/DateTimeDigitized
- 同步 MediaStore DATE_TAKEN


## 1.2 修复与改进

- 统一时间改为取两张照片 `DATE_MODIFIED` 的较早值
- 写入 EXIF 后恢复实际文件 mtime，避免照片跳到相册最顶部
- “统一时间”按钮整体下移并扩大点击区域
- 照片网格支持双指捏合，每行可在 2～7 张之间调整
