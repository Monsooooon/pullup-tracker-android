# 边缘相册 Photo Edge Viewer

功能：

- 读取 Android 系统媒体库中的全部相册和照片
- Glide 缩略图加载，适合数百到数千张照片
- 点击照片左右边缘切换，不需要左右滑动
- 淡出 / 淡入过渡
- 长按选择两张照片
- 请求系统授权后，把两张照片的 DATE_TAKEN / DATE_MODIFIED 统一为较早值
- 完全离线

## GitHub Actions

仓库原有 workflow 会执行：

```bash
unzip -o source.zip -d source
cd source
gradle assembleDebug
```

构建完成后在 Actions → 对应运行 → Artifacts 下载 APK。

## 说明

Android 11 及以上修改他人创建的媒体文件时会显示系统授权弹窗。部分厂商相册可能按自己的数据库或 EXIF 排序，因此即使 MediaStore 时间更新成功，也可能需要重启相册或重新扫描。


## 1.1 修复

- 顶部“选择相册”按钮弹出明确的相册列表
- 修改时间时同时写入 EXIF DateTime/DateTimeOriginal/DateTimeDigitized
- 同步 MediaStore DATE_TAKEN


## 1.2 修复与改进

- 统一时间改为取两张照片 `DATE_MODIFIED` 的较早值
- 写入 EXIF 后恢复实际文件 mtime，避免照片跳到相册最顶部
- “统一时间”按钮整体下移并扩大点击区域
- 照片网格支持双指捏合，每行可在 2～7 张之间调整


## 1.3 闪退修复

- 移除 RecyclerView 绑定阶段动态修改子项尺寸的逻辑
- 使用专用 SquareFrameLayout 保持缩略图为正方形
- 双指缩放只调整 GridLayoutManager 列数
- 文件 mtime 恢复失败不再导致整个修改流程失败


## 1.4 直接切换

- 点击照片左右边缘后立即替换图片
- 禁用 Glide 图片切换动画
- 点击“直接统一时间”后不显示应用内二次确认
- Android 11 及以上的系统写入授权弹窗属于系统强制安全限制，无法由应用关闭
