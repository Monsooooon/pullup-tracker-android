package com.yang.pulluptracker;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.widget.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity{
    LinearLayout root, heat, history; EditText input; TextView today, month, streak, tip; SharedPreferences sp; SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA);
    @Override public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("pullups",0); build(); refresh();}
    TextView tv(String s,int size,int style){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.rgb(24,24,27));v.setTypeface(Typeface.DEFAULT,style);v.setPadding(0,8,0,8);return v;}
    TextView card(String title,String value){TextView v=tv(title+"\n"+value,18,Typeface.BOLD);v.setBackgroundColor(Color.WHITE);v.setPadding(28,22,28,22);return v;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    void build(){ScrollView sv=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(32,42,32,42);root.setBackgroundColor(Color.rgb(247,248,250));sv.addView(root);setContentView(sv);
        root.addView(tv("💪 引体记录",30,Typeface.BOLD)); tip=tv("晚上输入计数器当前总数，App 会自动和上一次读数做差。",15,Typeface.NORMAL);tip.setTextColor(Color.rgb(82,82,91));root.addView(tip);
        input=new EditText(this);input.setHint("今天计数器读数，例如 386");input.setInputType(2);input.setTextSize(22);input.setPadding(18,14,18,14);root.addView(input,new LinearLayout.LayoutParams(-1,-2));
        Button save=btn("保存今天读数");root.addView(save,new LinearLayout.LayoutParams(-1,-2));save.setOnClickListener(v->saveToday(false));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);today=card("今天完成","0 个");month=card("本月累计","0 个");row.addView(today,new LinearLayout.LayoutParams(0,-2,1));row.addView(month,new LinearLayout.LayoutParams(0,-2,1));root.addView(row);
        streak=card("连续训练","0 天");root.addView(streak,new LinearLayout.LayoutParams(-1,-2));
        Button reset=btn("本月计数器已重置，从当前读数重新开始");root.addView(reset,new LinearLayout.LayoutParams(-1,-2));reset.setOnClickListener(v->saveToday(true));
        root.addView(tv("最近 180 天热力图",20,Typeface.BOLD));heat=new LinearLayout(this);heat.setOrientation(LinearLayout.VERTICAL);root.addView(heat);
        root.addView(tv("历史记录",20,Typeface.BOLD));history=new LinearLayout(this);history.setOrientation(LinearLayout.VERTICAL);root.addView(history);
    }
    void saveToday(boolean reset){String s=input.getText().toString().trim(); if(s.isEmpty()){toast("先输入计数器读数");return;} int val;try{val=Integer.parseInt(s);}catch(Exception e){toast("请输入数字");return;} String d=fmt.format(new Date()); SharedPreferences.Editor ed=sp.edit(); int daily=0; if(!reset){String prevDate=prevDate(d); if(prevDate!=null){int prev=sp.getInt("counter_"+prevDate,val); daily=Math.max(0,val-prev);} }
        ed.putInt("counter_"+d,val); ed.putInt("daily_"+d,daily); ed.apply(); input.setText(""); ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0); toast(reset?"已按重置保存":"已保存"); refresh(); }
    String prevDate(String d){ArrayList<String> ds=dates(); String prev=null; for(String x:ds) if(x.compareTo(d)<0) prev=x; return prev;}
    ArrayList<String> dates(){Map<String,?> all=sp.getAll();TreeSet<String> set=new TreeSet<>();for(String k:all.keySet())if(k.startsWith("counter_"))set.add(k.substring(8));return new ArrayList<>(set);} 
    int daily(String d){return sp.getInt("daily_"+d,0);} 
    void refresh(){String d=fmt.format(new Date()); today.setText("今天完成\n"+daily(d)+" 个"); month.setText("本月累计\n"+monthSum()+" 个"); streak.setText("连续训练\n"+streakDays()+" 天"); drawHeat(); drawHistory();}
    int monthSum(){String m=new SimpleDateFormat("yyyy-MM",Locale.CHINA).format(new Date());int sum=0;for(String d:dates()) if(d.startsWith(m))sum+=daily(d);return sum;}
    int streakDays(){Calendar c=Calendar.getInstance();int n=0;while(true){String d=fmt.format(c.getTime()); if(daily(d)>0){n++; c.add(Calendar.DATE,-1);} else break;}return n;}
    void drawHeat(){heat.removeAllViews();Calendar c=Calendar.getInstance();c.add(Calendar.DATE,-179);for(int r=0;r<30;r++){LinearLayout row=new LinearLayout(this);for(int col=0;col<6;col++){String d=fmt.format(c.getTime());TextView cell=new TextView(this);int x=daily(d);cell.setText(x>0?"":" ");cell.setTextSize(6);cell.setBackgroundColor(color(x));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(38,38);lp.setMargins(3,3,3,3);row.addView(cell,lp);c.add(Calendar.DATE,1);}heat.addView(row);} }
    int color(int x){if(x<=0)return Color.rgb(229,231,235); if(x<10)return Color.rgb(187,247,208); if(x<30)return Color.rgb(74,222,128); if(x<60)return Color.rgb(22,163,74); return Color.rgb(21,128,61);} 
    void drawHistory(){history.removeAllViews();ArrayList<String> ds=dates();Collections.reverse(ds);int n=0;for(String d:ds){TextView v=tv(d+"    "+daily(d)+" 个    读数 "+sp.getInt("counter_"+d,0),16,Typeface.NORMAL);history.addView(v);if(++n>=30)break;}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
